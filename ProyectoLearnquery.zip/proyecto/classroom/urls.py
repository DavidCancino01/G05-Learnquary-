from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('menu/', views.menu, name='menu'),
    path('classroom/<str:classroom_id>/', views.classroom, name='classroom'),
    path('classroom/<str:classroom_id>/question/', views.ask_question, name='ask_question'),
    path('classroom/<str:classroom_id>/question/<int:question_id>/', views.view_question, name='view_question'),
    path('classroom/<str:classroom_id>/question/<int:question_id>/answer/', views.give_answer, name='give_answer'),
]
