from django import forms
from .models import Student, Question

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['name', 'rut', 'password', 'education_level']

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['statement', 'date', 'question_id']
