from django.urls import path
from . import views

urlpatterns = [
    # Ruta para la página de inicio
    path('', views.index, name='index'),

    # Ruta para el formulario de registro de estudiantes
    path('registro/', views.registro, name='registro'),

    # Ruta para el ingreso al aula de un nivel educativo y área específica
    path('aula/<str:nivel_educativo>/<str:area>/', views.aula, name='aula'),

    # Ruta para enviar preguntas al profesor
    path('enviar_pregunta/', views.enviar_pregunta, name='enviar_pregunta'),

    # Otras rutas que puedes agregar según tus necesidades
]
