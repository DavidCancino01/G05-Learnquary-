from django.contrib import admin
from .models import NivelEducativo, AreaAsignatura, Pregunta, Respuesta

# Registrar tus modelos en el administrador de Django

admin.site.register(NivelEducativo)
admin.site.register(AreaAsignatura)
admin.site.register(Pregunta)
admin.site.register(Respuesta)
