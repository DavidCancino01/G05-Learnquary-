from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    # Lógica para la página de inicio
    return HttpResponse("Página de inicio")

def registro(request):
    if request.method == 'POST':
        # Obtener los datos del formulario de registro
        nombre = request.POST['nombre']
        rut = request.POST['rut']
        email = request.POST['email']
        nivel_educativo = request.POST['nivel_educativo']
        contrasena = request.POST['contrasena']

        # Realizar acciones con los datos (guardar en la base de datos, etc.)

        # Redireccionar a una página de éxito o mostrar un mensaje de éxito
        return HttpResponse("Registro exitoso")
    else:
        # Renderizar el formulario de registro
        return render(request, 'registro.html')

def aula(request, nivel_educativo, area):
    # Lógica para el ingreso al aula de un nivel educativo y área específica
    return HttpResponse(f"Aula {nivel_educativo} - {area}")

def enviar_pregunta(request):
    if request.method == 'POST':
        # Obtener los datos del formulario de envío de pregunta
        pregunta = request.POST['pregunta']

        # Realizar acciones con la pregunta (enviar al profesor, guardar en la base de datos, etc.)

        # Redireccionar a una página de éxito o mostrar un mensaje de éxito
        return HttpResponse("Pregunta enviada con éxito")
    else:
        # Renderizar el formulario de envío de pregunta
        return render(request, 'enviar_pregunta.html')
