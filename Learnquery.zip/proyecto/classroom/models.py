from django.db import models

class Alumno(models.Model):
    rut = models.CharField(max_length=20)
    email = models.EmailField()
    contrasena = models.CharField(max_length=100)
    numero_matricula = models.IntegerField()
    nombre = models.CharField(max_length=100)

    def getRut(self):
        return self.rut

    def getNombre(self):
        return self.nombre

    def getEmail(self):
        return self.email

    def getContrasena(self):
        return self.contrasena

    # Otras operaciones y métodos relacionados con el Alumno

class Aula(models.Model):
    ID = models.CharField(max_length=20)
    nivel = models.CharField(max_length=100)

    # Otras operaciones y métodos relacionados con el Aula

class Pregunta(models.Model):
    ID = models.CharField(max_length=20)
    fecha = models.DateField()
    enunciado = models.TextField()

    # Otras operaciones y métodos relacionados con la Pregunta

class Respuesta(models.Model):
    ID = models.CharField(max_length=20)
    enunciado = models.TextField()
    fecha = models.DateField()

    # Otras operaciones y métodos relacionados con la Respuesta

class Profesor(models.Model):
    rut = models.CharField(max_length=20)
    nombre = models.CharField(max_length=100)
    email = models.EmailField()
    contrasena = models.CharField(max_length=100)
