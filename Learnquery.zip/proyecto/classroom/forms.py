from django import forms

class RegistroForm(forms.Form):
    nombre = forms.CharField(max_length=100)
    rut = forms.CharField(max_length=12)
    email = forms.EmailField()
    nivel_educativo = forms.CharField(max_length=100)
    contrasena = forms.CharField(widget=forms.PasswordInput())
