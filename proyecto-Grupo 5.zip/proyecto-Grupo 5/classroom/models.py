from django.db import models
from django.apps import apps


class Student(models.Model):
    name = models.CharField(max_length=100)
    rut = models.CharField(max_length=12)
    password = models.CharField(max_length=100)
    education_level = models.CharField(max_length=20)

    def __str__(self):
        return self.name

class Teacher(models.Model):
    name = models.CharField(max_length=100)
    rut = models.CharField(max_length=12)
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Classroom(models.Model):
    classroom_id = models.CharField(max_length=50)
    level = models.CharField(max_length=20)

    def __str__(self):
        return self.classroom_id

class Question(models.Model):
    statement = models.TextField()
    date = models.DateField()
    question_id = models.CharField(max_length=50)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)

    def __str__(self):
        return self.statement

class Answer(models.Model):
    statement = models.TextField()
    date = models.DateField()
    answer_id = models.CharField(max_length=50)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)

    def __str__(self):
        return self.statement

