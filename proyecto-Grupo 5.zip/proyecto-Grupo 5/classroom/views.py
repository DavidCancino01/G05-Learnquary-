from django.shortcuts import render, get_object_or_404, redirect
from .forms import StudentForm, QuestionForm
from .models import Classroom, Question, Answer, Teacher

def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def menu(request):
    return render(request, 'menu.html')

def classroom(request, classroom_id):
    classroom = get_object_or_404(Classroom, classroom_id=classroom_id)
    return render(request, 'classroom.html', {'classroom': classroom})

def ask_question(request, classroom_id):
    classroom = get_object_or_404(Classroom, classroom_id=classroom_id)

    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.student = request.user.student  # Assuming you have authentication in place
            question.save()
            return redirect('classroom', classroom_id=classroom_id)
    else:
        form = QuestionForm()

    return render(request, 'ask_question.html', {'classroom': classroom, 'form': form})

def view_question(request, classroom_id, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'view_question.html', {'question': question})

def give_answer(request, classroom_id, question_id):
    question = get_object_or_404(Question, pk=question_id)

    if request.method == 'POST':
        statement = request.POST.get('statement')
        date = request.POST.get('date')
        answer_id = request.POST.get('answer_id')
        teacher = Teacher.objects.first()  # Assuming you have a teacher instance

        answer = Answer.objects.create(statement=statement, date=date, answer_id=answer_id,
                                       question=question, teacher=teacher)
        return redirect('view_question', classroom_id=classroom_id, question_id=question_id)

    return render(request, 'give_answer.html', {'question': question})
