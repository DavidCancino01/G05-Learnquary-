from django.shortcuts import render, get_object_or_404, redirect
from .models import Classroom, Student, Professor, Question, Answer
from .forms import StudentForm, ProfessorForm, QuestionForm

def home(request):
    classrooms = Classroom.objects.all()
    return render(request, 'home.html', {'classrooms': classrooms})

def about(request):
    return render(request, 'about.html')

def classroom_detail(request, classroom_id):
    classroom = get_object_or_404(Classroom, pk=classroom_id)
    students = Student.objects.filter(classroom=classroom)
    return render(request, 'classroom_detail.html', {'classroom': classroom, 'students': students})

def ask_question(request, classroom_id):
    classroom = get_object_or_404(Classroom, pk=classroom_id)

    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.student = request.user
            question.save()
            return redirect('classroom_detail', classroom_id=classroom_id)
    else:
        form = QuestionForm()

    return render(request, 'ask_question.html', {'classroom': classroom, 'form': form})
