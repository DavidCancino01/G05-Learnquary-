from django import forms
from .models import Student, Professor, Question

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = '__all__'

class ProfessorForm(forms.ModelForm):
    class Meta:
        model = Professor
        fields = '__all__'

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = '__all__'
