from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100)
    rut = models.CharField(max_length=20)
    password = models.CharField(max_length=100)
    education_level = models.CharField(max_length=20)

class Professor(models.Model):
    name = models.CharField(max_length=100)
    rut = models.CharField(max_length=20)
    password = models.CharField(max_length=100)

class Classroom(models.Model):
    id = models.AutoField(primary_key=True)
    level = models.CharField(max_length=20)

class Question(models.Model):
    statement = models.TextField()
    date = models.DateField(auto_now_add=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE)

class Answer(models.Model):
    statement = models.TextField()
    date = models.DateField(auto_now_add=True)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    professor = models.ForeignKey(Professor, on_delete=models.CASCADE)

