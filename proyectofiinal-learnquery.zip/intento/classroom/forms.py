from django import forms
from .models import Student, Professor, Question, Answer

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = '__all__'

class ProfessorForm(forms.ModelForm):
    class Meta:
        model = Professor
        fields = '__all__'

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ('statement',)

class AnswerForm(forms.ModelForm):
    class Meta:
        model = Answer
        fields = ('statement',)
