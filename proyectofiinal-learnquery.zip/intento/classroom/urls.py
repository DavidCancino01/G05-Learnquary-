from django.urls import path
from . import views
from classroom.views import StudentQuestionView, TeacherAnswerView
from .views import StudentQuestionView

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('login/<int:classroom_id>/', views.login, name='login'),
    path('classroom/', views.classroom, name='classroom'),  # Corrección aquí
    path('forum/', views.forum, name='forum'),
    path('question/<int:classroom_id>/', views.question, name='question'),
    path('student_question/', views.StudentQuestionView.as_view(), name='student_question'),
    path('add_message/', views.add_message, name='add_message'),
    path('teacher_answer/<int:question_id>/', TeacherAnswerView.as_view(), name='teacher_answer'),
]

