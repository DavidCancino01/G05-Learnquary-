from django.db import models
from django.contrib.auth.models import User

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    rut = models.CharField(max_length=20)
    password = models.CharField(max_length=100)
    education_level = models.CharField(max_length=20)

class Professor(models.Model):
    name = models.CharField(max_length=100)
    rut = models.CharField(max_length=20)
    password = models.CharField(max_length=100)

class Classroom(models.Model):
    id = models.AutoField(primary_key=True)
    level = models.CharField(max_length=20)

class Question(models.Model):
    statement = models.TextField()
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    answered = models.BooleanField(default=False)

class Answer(models.Model):
    statement = models.TextField()
question = models.ForeignKey('Question', on_delete=models.CASCADE)
teacher = models.ForeignKey(Professor, on_delete=models.CASCADE)
created_at = models.DateTimeField(auto_now_add=True)


class Message(models.Model):
    author = models.CharField(max_length=100)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)