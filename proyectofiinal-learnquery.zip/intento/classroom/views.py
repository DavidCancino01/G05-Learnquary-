from django.shortcuts import render, get_object_or_404, redirect
from .models import Classroom, Student, Professor, Question, Answer
from .forms import QuestionForm, ProfessorForm, StudentForm, AnswerForm
from django.views import View
from django.urls import reverse
from django.shortcuts import redirect
from django.urls import reverse_lazy
from django.views.generic.edit import CreateView
from django.http import HttpResponse

def home(request):
    classrooms = Classroom.objects.all()
    return render(request, 'home.html', {'classrooms': classrooms})

def about(request):
    return render(request, 'about.html')

from django.urls import reverse

def login(request, classroom_id=123):
    classroom = get_object_or_404(Classroom, id=classroom_id)
    students = Student.filter(classroom=classroom)
    error = None

    if request.method == 'POST':
        name = request.POST.get('name')
        rut = request.POST.get('rut')
        password = request.POST.get('password')
        level = int(request.POST.get('level'))

        # Verificar si el estudiante existe y tiene acceso al classroom
        student = Student.filter(name=name, rut=rut, password=password, level=level, classroom=classroom).first()
        if student:
            # Redirigir al estudiante a classroom.html
            return redirect('classroom')

        # Mostrar mensaje de error si los datos son incorrectos
        error = 'Datos incorrectos'

    return render(request, 'login.html', {'classroom_id': classroom_id, 'error': error})


def question(request, classroom_id):
    classroom = get_object_or_404(Classroom, id=classroom_id)
    consulta_enviada = False  # Variable de contexto para controlar la visibilidad del mensaje

    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.student = request.user
            question.classroom = classroom
            question.save()
            consulta_enviada = True  # Establecer la variable de contexto a True si se envía el formulario
    else:
        form = QuestionForm()

    return render(request, 'classroom.html', {'classroom': classroom, 'form': form, 'consulta_enviada': consulta_enviada})

class StudentQuestionView(View):
    def get(self, request):
        return render(request, 'student_question.html')

    def post(self, request):
        statement = request.POST.get('question')
        # Guardar la pregunta en la base de datos
        question = Question.objects.create(statement=statement)
        pregunta_enviada = True  # Establecer la variable de contexto a True si se envía el formulario
        return render(request, 'home.html', {'pregunta_enviada': pregunta_enviada})

class TeacherAnswerView(View):
    def get(self, request, question_id):
        question = get_object_or_404(Question, id=question_id)
        return render(request, 'teacher_answer.html', {'question': question})

    def post(self, request, question_id):
        statement = request.POST.get('statement')

        # Verificar si el profesor existe
        teacher = get_object_or_404(Professor, id=request.user.id)
        if teacher:
            # Obtener la pregunta y guardar la respuesta en la base de datos
            question = get_object_or_404(Question, id=question_id)
            answer = Answer.objects.create(statement=statement, question=question, teacher=teacher)
            return render(request, 'answer_submitted.html')
        else:
            return render(request, 'teacher_answer.html', {'error': 'No se pudo enviar la respuesta'})

def forum(request):
    messages = Message.objects.all()
    return render(request, 'forum.html', {'messages': messages})

def add_message(request):
    if request.method == 'POST':
        author = request.POST['author']
        content = request.POST['content']
        message = Message.objects.create(author=author, content=content)
        return redirect('forum')
    else:
        return render(request, 'add_message.html')

def classroom(request):
    classroom_id = 123  # Aquí deberías obtener el valor correcto del classroom_id
    classroom_name = "Álgebra"  # Nombre del aula fijo
    classroom_level = request.GET.get('level', '')  # Obtener el nivel del menú
    
    context = {
        'classroom_id': classroom_id,
        'classroom_name': classroom_name,
        'classroom_level': classroom_level
    }
    
    return render(request, 'classroom.html', context)

class StudentQuestionView(CreateView):
    model = Question
    fields = ['statement']
    template_name = 'student_question.html'
    success_url = '/'  # Redirigir al usuario a la página principal después de enviar la pregunta

    def form_valid(self, form):
        form.instance.student = self.request.user
        return super().form_valid(form)

    def post(self, request, *args, **kwargs):
        form_class = self.get_form_class()
        form = self.get_form(form_class)

        if form.is_valid():
            return self.form_valid(form)
        else:
            return self.form_invalid(form)

def student_question(request):
    if request.method == 'POST':
        # Procesa el formulario y realiza las operaciones necesarias

        # Establece el mensaje de confirmación
        message = "Consulta enviada"
        return HttpResponse(message)

    return render(request, 'home.html')