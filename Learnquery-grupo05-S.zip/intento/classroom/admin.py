from django.contrib import admin
from .models import Student, Professor, Classroom, Question, Answer

admin.site.register(Student)
admin.site.register(Professor)
admin.site.register(Classroom)
admin.site.register(Question)
admin.site.register(Answer)

# Register your models here.
